#!/bin/sh

echo “*******************************************************”
echo "* 参数：--name=活动域名  --port=使用端口 --webPath=默认使用/data/TomcatOtherCluster/web"
echo ""
echo "* 默认JDK位置：/usr/local/java/jdk1.8.0_51 ，如果不是默认可以使用--jdk=XXXXX参数"
echo "* 默认CATALINA_HOME位置：/usr/local/tomcat , 如果不是默认可以使用--tomcatSource=XXXXX"
echo "* 默认使用的端口前缀分别是：（关闭：81，启动： 80 , AJP: 81），因此端口要以80开头哦"
echo ""
echo "* TODOs 如果有优化建议到这：http://git.gyyx.cn/doc/dev.cn/issues， 如想修改请到这：http://git.gyyx.cn/doc/dev.cn/tree/master/tomcat_install"
echo "* 1 . 如果存在多个web站点目录，则扫描多个目录下站点的端口"
echo "* "
echo “*******************************************************”
echo ""


# 1. Deal With Input Params
for a in $*
    do
        r=`echo $a | sed "s/--//g"`
        eval $r
    done

# 2. Validate Input Params

if [ "$name" = "" ];then
    echo "{ --name=xxx } is needed!"
    exit -1
fi

if [ "$port" = "" ];then
    echo "{ --port=xxx } is needed!"
    exit -1
fi

# 2.1 判断jdk路径
#JDK_PATH="/usr/local/java/jdk1.8.0_51"
JDK_PATH="/usr/bin/java"
if [ "$jdk" ]; then
    JDK_PATH=$jdk
fi    

echo "Checking jdk path: $JDK_PATH"
if [ -x "$JDK_PATH/bin/java" ]; then
    echo "Java path can use. GO!"
else
    echo " Current JDK cant not be used. Param {--jdk=xxxx} is error or needed. Please fix it."
    exit -1
fi

# 2.2 判断Tomcat根路径

CATALINA_HOME_PATH="/data/tomcat"
if [ "$tomcatSource" ]; then
    CATALINA_HOME_PATH=$tomcatSource
fi 

echo "Checking catalina home path: $CATALINA_HOME_PATH"
if [ -x "$CATALINA_HOME_PATH/bin/startup.sh" ]; then
    echo "CATALINA_HOME path can use. GO!"
else
    echo " Current CATALINA_HOME cant not be used. Param {--tomcatSource==xxxx} is error or needed. Please fix it."
    exit -1
fi

# 3. 检验/data/TomcatOtherCluster/web 所有端口占用情况，并拷贝资源

tomcatRootPath='/data/TomcatCluster'

if [ $webPath ]; then
    tomcatRootPath="$webPath"
    echo "----- 1. 目标扫描路径： $tomcatRootPath"
  else
   echo "----- 1. 目标扫描路径： $tomcatRootPath"
fi


# 3. 1 检验web目录下是否有同名的Tomcat目录存在
targetTomcatName=$port"-"$name
targetTomcatPath=$tomcatRootPath"/"$targetTomcatName

OldIFS=$IFS                                                                                                                              
IFS=$','                                                                                                                                 
webPaths=($webPath) 
for p in ${webPaths[@]}                                                                                                                     
do                                                                                                                                         
    echo "path: $p"
done                                                                                                                                                                                                                                                                                  
IFS=$OldIFS  


if [ -d "$targetTomcatPath" ]; then
    echo "----- 目标Tomcat[$targetTomcatPath]已经存在，Tomcat站点生成停止！"
    exit -1
fi


# 3.2 检查端口是否被占用以及资源拷贝


ajp_port_prefix=82
http_port_prefix=80
shutdown_port_prefix=81
port_subfix=${port:0-2}

new_ajp_port=$ajp_port_prefix$port_subfix
new_http_port=$http_port_prefix$port_subfix
new_shutdown_port=$shutdown_port_prefix$port_subfix

# 预定义函数Start
# 拷贝资源 
copyTomcatSourceToTarget()
{
    echo '----- Starting Copy...'
    echo "----- Create dir $targetTomcatPath"
    `mkdir -p $targetTomcatPath`
    cp -r ./tomcat-source/* $targetTomcatPath

    chown -R tomcat:tomcat "$targetTomcatPath"
    echo  '----- Copy source end.'

    echo '----- Create logs dir...'
    dmanuallogs="/data/logs/$targetTomcatName"
    echo "----- Logs dir: $dmanuallogs/logs/manual"
    mkdir -p "$dmanuallogs/logs/manual"
    chown -R  tomcat:tomcat "$dmanuallogs"
    daccesslogs="/data/weblog/$targetTomcatName"
    echo "----- Logs dir: $daccesslogs/accesslogs"
    mkdir -p "$daccesslogs/accesslogs"
    mkdir -p "$daccesslogs/logs"
    touch "$daccesslogs/logs/catalina.out"
    chown -R  tomcat:tomcat "$daccesslogs"
    echo "----- Create temp dir..."
    echo "----- Create work dir..."
    dworkdir="/tmp/tomcattmp/$targetTomcatName"
    mkdir -p "$dworkdir/work"
    mkdir -p "$dworkdir/temp"
    chown -R  tomcat:tomcat "$dworkdir"
    
    echo "----- 资源拷贝授权结束 "

    confServerXml=$targetTomcatPath/conf/server.xml
    echo "----- 【修改$confServerXml文件内容】"

    appBasePath=$targetTomcatPath"/website"
    # 修改端口
    sed -i "s/Server port=\"[0-9]\{4\}\"/Server port=\"$new_shutdown_port\"/g" $confServerXml
    sed -i "s/Connector port=\"[0-9]\{4\}\" protocol=\"HTTP\/1.1\"/Connector port=\"$new_http_port\" protocol=\"org.apache.coyote.http11.Http11NioProtocol\"/g" $confServerXml
    sed -i "s/Connector port=\"[0-9]\{4\}\" protocol=\"AJP\/1.3\" redirectPort=\"8443\" /Connector port=\"$new_ajp_port\" protocol=\"AJP\/1.3\" redirectPort=\"8443\" /g" $confServerXml
    # 修改路径 替换conf/server.xml字符串Host[name] Host[appBase] Host[workDir] Context[docBase] Value[dirctory] Value[prefix]
    sed -i "s!Host name=\"[[:punct:]\|[:alnum:]]\+\"!Host name=\"$name\"!g" $confServerXml    
    sed -i "s!appBase=\"[[:punct:]\|[:alnum:]]\+\"!appBase=\"$appBasePath\"!g" $confServerXml    
    sed -i "s!workDir=\"[[:punct:]\|[:alnum:]]\+\"!workDir=\"$dworkdir/work\"!g" $confServerXml    
    sed -i "s!docBase=\"[[:punct:]\|[:alnum:]]\+\"!docBase=\"$appBasePath/ROOT\"!g" $confServerXml    
    sed -i "s!directory=\"[[:punct:]\|[:alnum:]]\+\"!directory=\"$daccesslogs/accesslogs\"!g" $confServerXml    
    sed -i "s!prefix=\"[[:punct:]\|[:alnum:]]\+\" suffix=\".txt\"!prefix=\"$name\_access\_log\"  suffix=\".txt\"!g" $confServerXml    
    

 
    binConsoleSh=$targetTomcatPath/bin/console.sh
    echo "----- 【修改$binConsoleSh文件内容】"
    # export tomcatName=xxxxxxxx
    chmod 755 $binConsoleSh
    sed -i "s!export tomcatName=[[:punct:]\|[:alnum:]]\+!export tomcatName=$targetTomcatName!g" $binConsoleSh

    # export JRE_HOME=/usr/local/java/jdk1.8.0_51
    sed -i "s!export JRE_HOME=[[:punct:]\|[:alnum:]]\+!export JRE_HOME=$JDK_PATH!g" $binConsoleSh

    # export CATALINA_HOME=/usr/local/tomcat
    sed -i "s!export CATALINA_HOME=[[:punct:]\|[:alnum:]]\+!export CATALINA_HOME=$CATALINA_HOME_PATH!g" $binConsoleSh

    # export CATALINA_BASE=/data/TomcatOtherCluster/web/xxxxxxxx
    sed -i "s!export CATALINA_BASE=[[:punct:]\|[:alnum:]]\+!export CATALINA_BASE=$targetTomcatPath!g" $binConsoleSh

    # export CATALINA_OUT=/data/weblog/xxxxx/logs/catalina.out
    sed -i "s!export CATALINA_OUT=[[:punct:]\|[:alnum:]]\+!export CATALINA_OUT=$daccesslogs/logs/catalina.out!g" $binConsoleSh

   # export CATALINA_TMPDIR=/tmp/tomcattmp/xxxxxx/temp
    sed -i "s!export CATALINA_TMPDIR=[[:punct:]\|[:alnum:]]\+!export CATALINA_TMPDIR=$dworkdir/temp!g" $binConsoleSh

}
# 预定义函数End

mathPattern=$ajp_port_prefix$port_subfix"\|"$http_port_prefix$port_subfix"\|"$shutdown_port_prefix$port_subfix

echo "------ 2. 检查这些接口($mathPattern)是否被占用"
for element in `ls $tomcatRootPath`
    do  
        if [ -d $tomcatRootPath"/"$element ]; then
            isExist=`sed -n "/$mathPattern/p" $tomcatRootPath/$element/conf/server.xml`
            if [ "$isExist" ]; then
                   echo "----- 3. 端口[$mathPattern]已经被占用，Tomcat站点生成停止！"
                   exit -1
            fi
        fi
    done

echo '----- 3. 开始拷贝Tomcat站点资源'
copyTomcatSourceToTarget;

#create tomcat start script 

# cp ./start_template /etc/init.d/$name
# sed -i "s/export CATALINA_BASE=/export CATALINA_BASE=\/data\/$name/g" /etc/init.d/$name
# chmod 755 /etc/init.d/$name
# echo "create success! you start console \"/etc/init.d/$name start\""

echo “----- 创建Tomcat结束”
